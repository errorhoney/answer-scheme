package com.example.answerscheme;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText ps, ID;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ID = (EditText)findViewById(R.id.ID);
        ps = (EditText)findViewById(R.id.pswd);
    }

    public void logbtn(View view) {
        String user = ID.getText().toString();
        String pass = ps.getText().toString();

        background bg = new background(this);
        bg.execute(ID,ps);

        }
    }
}
